from django.apps import AppConfig


class PsychologicalmanagementConfig(AppConfig):
    name = 'psychologicalManagement'
