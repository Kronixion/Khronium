from django.apps import AppConfig


class TimemanagementConfig(AppConfig):
    name = 'timeManagement'
