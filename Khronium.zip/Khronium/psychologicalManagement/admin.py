from django.contrib import admin
from .models import PsychologicalModel

admin.site.register(PsychologicalModel)
