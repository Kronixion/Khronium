from django.apps import AppConfig


class ProjectmanagementConfig(AppConfig):
    name = 'projectManagement'
